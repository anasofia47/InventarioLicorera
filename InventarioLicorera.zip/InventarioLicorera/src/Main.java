import vista2.LoginVista2;
import controlador2.LoginController;

public class Main {
    public static void main(String[] args) {
        LoginVista2 vista = new LoginVista2();
        new LoginController(vista);
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }
}
