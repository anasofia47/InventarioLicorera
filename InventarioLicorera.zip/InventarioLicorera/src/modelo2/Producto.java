
package modelo2;


public class Producto {
    
    private String nombre;
    private String cantidad;
    private String tipo;

    public Producto(String nombre, String cantidad, String tipo) {
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.tipo = tipo;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCantidad() {
        return cantidad;
    }

    public String getTipo() {
        return tipo;
    }
}
