
package controlador2;

import vista2.InventarioVista;
import modelo2.Producto;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;

public class InventarioController {
    
    private InventarioVista vista;
    private DefaultTableModel modeloTabla;

    public InventarioController(InventarioVista vista) {
        this.vista = vista;

        // Cargar el modelo de la tabla
        modeloTabla = (DefaultTableModel) vista.tablaProductos.getModel();

        inicializarEventos();
    }

    private void inicializarEventos() {

        // Botón Agregar
        vista.btnAgregar.addActionListener(e -> agregarProducto());

        // Botón Limpiar
        vista.btnLimpiar.addActionListener(e -> limpiarCampos());
        
        vista.btnBuscar.addActionListener(e -> buscarProducto());
    }

    private void agregarProducto() {

        String nombre = vista.txtNombre.getText();
        String cantidad = vista.txtCantidad.getText();
        String tipo = "";

        // Detectar radio button seleccionado
        if (vista.rbLicor.isSelected()) {
            tipo = "Licor";
        } else if (vista.rbCerveza.isSelected()) {
            tipo = "Cerveza";
        } else if (vista.rbVino.isSelected()) {
            tipo = "Vino";
        } else {
            JOptionPane.showMessageDialog(vista, "Debes seleccionar un tipo de bebida");
            return;
        }

        if (nombre.isEmpty() || cantidad.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Todos los campos son obligatorios");
            return;
        }

        // Crear producto
        Producto p = new Producto(nombre, cantidad, tipo);

        // Insertar en la tabla
        modeloTabla.addRow(new Object[]{p.getNombre(), p.getCantidad(), p.getTipo()});
        vista.lblTotal.setText("Total productos: " + modeloTabla.getRowCount());

        limpiarCampos();
    }

    private void limpiarCampos() {
        vista.txtNombre.setText("");
        vista.txtCantidad.setText("");
        vista.grupoBebidas.clearSelection();
    }
    
    private void buscarProducto() {

    String texto = vista.txtBuscar.getText().trim().toLowerCase();

    if (texto.isEmpty()) {
        JOptionPane.showMessageDialog(vista, "Ingrese un nombre para buscar");
        return;
    }

    boolean encontrado = false;

    for (int i = 0; i < modeloTabla.getRowCount(); i++) {
        Object valor = modeloTabla.getValueAt(i, 0);
        if (valor == null) {
            continue;
        }
        
        String nombre = valor.toString().toLowerCase();
        if (nombre.contains(texto)) {
            vista.tablaProductos.setRowSelectionInterval(i, i);
            encontrado = true;
            break;
        }
    }

    if (!encontrado) {
        JOptionPane.showMessageDialog(vista, "Producto no encontrado");
    }
 }
}
