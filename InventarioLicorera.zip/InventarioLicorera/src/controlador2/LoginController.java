
package controlador2;

import vista2.LoginVista2;
import vista2.MenuPrincipal;
import javax.swing.JOptionPane;

public class LoginController {
    
    private LoginVista2 vista;

    public LoginController(LoginVista2 vista) {
        this.vista = vista;
        inicializarEventos();
    }
    
    private void inicializarEventos() {
        
        vista.btnIngresar.addActionListener(e -> {
            String usuario = vista.txtUsuario.getText();
            String contraseña = new String(vista.txtContraseña.getPassword());
            
            if (usuario.equals("admin") && contraseña.equals("1234")) {
                MenuPrincipal menu = new MenuPrincipal();
                menu.setVisible(true);
                vista.dispose();
            } else {
                JOptionPane.showMessageDialog(vista, "Usuario o contraseña incorrectos");
            }
        });
    }
}
